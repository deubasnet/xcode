//
//  ViewController.swift
//  PokerWar
//
//  Created by Deu Basnet on 10/15/18.
//  Copyright © 2018 Deu Basnet. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var LeftImageview: UIImageView!
    
    @IBOutlet weak var RightImageView: UIImageView!
    
    @IBOutlet weak var LeftScoreLable: UILabel!

    @IBOutlet weak var RightScoreLable: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    var LeftScore = 0
    var RightScore = 0
    
    @IBAction func dealTapped(_ sender: Any) {
        // Randomize two number
        let LeftRandomNumber = arc4random_uniform(13) + 2
        // print("Left random number is: \(LeftRandomNumber)")
        
        let RightRandomNumber = arc4random_uniform(13) + 2
        // print("Right random number is: \(RightRandomNumber)")
        
        // Change the image of views
        LeftImageview.image = UIImage(named: "card\(LeftRandomNumber)")
        RightImageView.image = UIImage(named: "card\(RightRandomNumber)")
        
        // Comapre the mumber
        if LeftRandomNumber > RightRandomNumber {
            // Update the score
            LeftScore += 1
            
            // Update the lable
            LeftScoreLable.text = String(LeftScore)
        }
        else if RightRandomNumber > LeftRandomNumber {
            // Update the score
            RightScore += 1
            
            // Update the lable
            RightScoreLable.text = String(RightScore)
        }
        else if LeftRandomNumber == RightRandomNumber {
            
        }
    }
}


